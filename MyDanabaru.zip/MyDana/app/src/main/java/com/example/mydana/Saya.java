package com.example.mydana;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.content.DialogInterface;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import android.view.View;
import android.widget.ImageView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class Saya extends AppCompatActivity {

    private ImageButton btnScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saya);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationview3);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                // Tangani klik pada item menu di BottomNavigationView
                if (item.getItemId() == R.id.Beranda) {
                    handleHomeClick();
                } else if (item.getItemId() == R.id.Aktivitas) {
                    handleAktivitasClick();
                } else if (item.getItemId() == R.id.Dompet) {
                    handleDompetClick();
                } else if (item.getItemId() == R.id.Saya) {
                    handleSayaClick();
                }

                return true;
            }
        });
        ImageView keluarButton = findViewById(R.id.keluar);

        keluarButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showExitDialog();
            }
        });

        btnScan = findViewById(R.id.scan);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scanner();
            }
        });
    }
    private void Scanner(){
        ScanOptions options = new ScanOptions();
        options.setPrompt("Volume up to Flash on");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(StratScan.class);
        launcher.launch(options);
    }

    ActivityResultLauncher<ScanOptions> launcher = registerForActivityResult(new ScanContract(), result -> {
        if (result.getContents() != null){
            android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(Saya.this);
            builder.setTitle("QR SCANNER RESULT");
            builder.setMessage(result.getContents());
            builder.setPositiveButton("oke", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }).show();
        }
    });
    private void showExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Konfirmasi Keluar");
        builder.setMessage("Apakah Anda yakin ingin keluar?");

        builder.setPositiveButton("Ya", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });

        builder.setNegativeButton("Tidak", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void handleHomeClick() {
        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Home di sini
        Intent aktivitasIntent = new Intent(Saya.this, MainHome.class);
        startActivity(aktivitasIntent);
    }

    private void handleAktivitasClick() {
        Toast.makeText(getApplicationContext(), "Aktivitas", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Aktivitas di sini
        Intent aktivitasIntent = new Intent(Saya.this, Aktivitas.class);
        startActivity(aktivitasIntent);
    }

    private void handleDompetClick() {
        Toast.makeText(getApplicationContext(), "Dompet", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Dompet di sini
        Intent DompetIntent = new Intent(Saya.this, Dompet.class);
        startActivity(DompetIntent);
    }

    private void handleSayaClick() {
        Toast.makeText(getApplicationContext(), "Saya", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Saya di sini
        Intent aktivitasIntent = new Intent(Saya.this, Saya.class);
        startActivity(aktivitasIntent);
    }
}