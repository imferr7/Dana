package com.example.mydana;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class pindai extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pindai);
    }

}