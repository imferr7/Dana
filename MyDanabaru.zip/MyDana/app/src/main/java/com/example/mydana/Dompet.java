package com.example.mydana;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

public class Dompet extends AppCompatActivity {

    private ImageButton btnScan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dompet);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationview2);
        ImageButton backButton = findViewById(R.id.back);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click event for the back button
                Intent intent = new Intent(Dompet.this, MainHome.class); // Replace HomeActivity with the actual name of your home activity
                startActivity(intent);
                finish(); // Optional, depending on your navigation requirements
            }
        });

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                // Tangani klik pada item menu di BottomNavigationView
                if (item.getItemId() == R.id.Beranda) {
                    handleHomeClick();
                } else if (item.getItemId() == R.id.Aktivitas) {
                    handleAktivitasClick();
                } else if (item.getItemId() == R.id.Dompet) {
                    handleDompetClick();
                } else if (item.getItemId() == R.id.Saya) {
                    handleSayaClick();
                }

                return true;
            }
        });
        btnScan = findViewById(R.id.scan);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scanner();
            }
        });
    }
    private void Scanner(){
        ScanOptions options = new ScanOptions();
        options.setPrompt("Volume up to Flash on");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(StratScan.class);
        launcher.launch(options);
    }

    ActivityResultLauncher<ScanOptions> launcher = registerForActivityResult(new ScanContract(), result -> {
        if (result.getContents() != null){
            AlertDialog.Builder builder = new AlertDialog.Builder(Dompet.this);
            builder.setTitle("QR SCANNER RESULT");
            builder.setMessage(result.getContents());
            builder.setPositiveButton("oke", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }).show();
        }
    });

    private void handleHomeClick() {
        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Home di sini
        Intent aktivitasIntent = new Intent(Dompet.this, MainHome.class);
        startActivity(aktivitasIntent);
    }

    private void handleAktivitasClick() {
        Toast.makeText(getApplicationContext(), "Aktivitas", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Aktivitas di sini
        Intent aktivitasIntent = new Intent(Dompet.this, Aktivitas.class);
        startActivity(aktivitasIntent);
    }

    private void handleDompetClick() {
        Toast.makeText(getApplicationContext(), "Dompet", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Dompet di sini
        Intent DompetIntent = new Intent(Dompet.this, Dompet.class);
        startActivity(DompetIntent);
    }

    private void handleSayaClick() {
        Toast.makeText(getApplicationContext(), "Saya", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Saya di sini
        Intent aktivitasIntent = new Intent(Dompet.this, Saya.class);
        startActivity(aktivitasIntent);
    }
}