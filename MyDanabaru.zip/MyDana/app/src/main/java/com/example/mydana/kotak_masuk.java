package com.example.mydana;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import androidx.appcompat.app.AppCompatActivity;

public class kotak_masuk extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kotak_masuk);
        ImageButton backButton = findViewById(R.id.kembali);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Handle the click event for the back button
                Intent intent = new Intent(kotak_masuk.this, MainHome.class); // Replace HomeActivity with the actual name of your home activity
                startActivity(intent);
                finish(); // Optional, depending on your navigation requirements
            }
        });
    }
}