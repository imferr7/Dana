package com.example.mydana;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import com.journeyapps.barcodescanner.ScanContract;
import com.journeyapps.barcodescanner.ScanOptions;

import java.util.Scanner;

public class MainHome extends AppCompatActivity {
    private ImageView scannerImageView;
    private ImageView saldoImageView;
    private ImageView kirimImageView;
    private ImageView mintaImageView;
    private ImageView masukImageView;
    private View menuaktivitas;

    private ImageButton btnScan;
    private ImageView imgScan;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigationview);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                // Tangani klik pada item menu di BottomNavigationView
                if (item.getItemId() == R.id.Beranda) {
                    handleHomeClick();
                } else if (item.getItemId() == R.id.Dompet) {
                    handleDompetClick();
                } else if (item.getItemId() == R.id.Saya) {
                    handleSayaClick();
                }
                return true;
            }
        });

        // Inisialisasi ImageView
        scannerImageView = findViewById(R.id.scanner);
        saldoImageView = findViewById(R.id.saldo);
        kirimImageView = findViewById(R.id.kirim);
        mintaImageView = findViewById(R.id.minta);
        masukImageView= findViewById(R.id.kotakmasuk);
        menuaktivitas = findViewById(R.id.Aktivitas);

        scannerImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tangani klik untuk ImageView scanner
                Intent scannerIntent = new Intent(MainHome.this, pindai.class);
                startActivity(scannerIntent);
            }
        });

        saldoImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tangani klik untuk ImageView saldo
                Intent saldoIntent = new Intent(MainHome.this, isisaldo.class);
                startActivity(saldoIntent);
            }
        });

        kirimImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tangani klik untuk ImageView kirim
                Intent kirimIntent = new Intent(MainHome.this, kirim.class);
                startActivity(kirimIntent);
            }
        });

        mintaImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tangani klik untuk ImageView minta
                Intent mintaIntent = new Intent(MainHome.this, minta.class);
                startActivity(mintaIntent);
            }
        });
        masukImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tangani klik untuk ImageView minta
                Intent mintaIntent = new Intent(MainHome.this, kotak_masuk.class);
                startActivity(mintaIntent);
            }
        });

        menuaktivitas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tangani klik untuk ImageView scanner
                Intent imp = new Intent(MainHome.this, Aktivitas.class);
                startActivity(imp);
            }
        });
        btnScan = findViewById(R.id.scan);
        imgScan = findViewById(R.id.scanner);

        btnScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scanner();
            }
        });
        imgScan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Scanner();
            }
        });
    }
    private void Scanner(){
        ScanOptions options = new ScanOptions();
        options.setPrompt("Volume up to Flash on");
        options.setBeepEnabled(true);
        options.setOrientationLocked(true);
        options.setCaptureActivity(StratScan.class);
        launcher.launch(options);
    }

    ActivityResultLauncher<ScanOptions> launcher = registerForActivityResult(new ScanContract(), result -> {
        if (result.getContents() != null){
            AlertDialog.Builder builder = new AlertDialog.Builder(MainHome.this);
            builder.setTitle("QR SCANNER RESULT");
            builder.setMessage(result.getContents());
            builder.setPositiveButton("oke", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }
            }).show();
        }
    });

    private void handleHomeClick() {
        Toast.makeText(getApplicationContext(), "Home", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Home di sini
        Intent HomeIntent = new Intent(MainHome.this, MainHome.class);
        startActivity(HomeIntent);
    }

    private void handleDompetClick() {
        Toast.makeText(getApplicationContext(), "Dompet", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Dompet di sini
        Intent DompetIntent = new Intent(MainHome.this, Dompet.class);
        startActivity(DompetIntent);
    }

    private void handleSayaClick() {
        Toast.makeText(getApplicationContext(), "Saya", Toast.LENGTH_LONG).show();
        // Tambahkan logika atau intent untuk menu Saya di sini
        Intent SayaIntent = new Intent(MainHome.this, Saya.class);
        startActivity(SayaIntent);
    }
}
