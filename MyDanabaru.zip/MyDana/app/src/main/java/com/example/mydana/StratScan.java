package com.example.mydana;

import com.journeyapps.barcodescanner.CaptureActivity;

public class StratScan extends CaptureActivity {
}
