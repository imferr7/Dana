package com.example.mydana;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Menunda transisi ke aktivitas lain
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                // Memulai aktivitas baru setelah penundaan
                Intent intent = new Intent(MainActivity.this, MainHome.class);
                startActivity(intent);

                // Menutup aktivitas saat ini jika diinginkan
                finish();
            }
        }, 2000); // Penundaan dalam milidetik (contohnya, 2000ms atau 2 detik)
    }
}
